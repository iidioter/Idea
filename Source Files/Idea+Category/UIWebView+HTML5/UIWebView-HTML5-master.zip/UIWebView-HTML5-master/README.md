UIWebView-HTML5
===============

This project is a UIWebView category about HTML5 methods including basic JavaScript functions, canvas API and others(comming soon...).


Note: This category should be used with "UIColor+change.h" Category together 
which can be found in another project named "UIColor-change":
https://github.com/duzixi/UIColor-Change


